var buttonColors = ["red", "blue", "green", "yellow"];

var gamePattern = [];
var userClickedPattern = [];

var started = false //to keep track of game play

var level = 0;

$(document).keypress(function () {
    if (!started) {
        $("#level-title").text("Level " +  level);
        NextSequence();
        started = true;
    }
});

$(".btn").click(function () {
    var chosencolor = $(this).attr("id");
    userClickedPattern.push(chosencolor);
    playSound(chosencolor);
    animatepress(chosencolor);

    CheckAnswer(userClickedPattern.length - 1);
})

function CheckAnswer(currentLevel) {
    if (gamePattern[currentLevel] === userClickedPattern[currentLevel]) {
        console.log("success");

        if (userClickedPattern.length === gamePattern.length) {
            setTimeout(function () {
                NextSequence();
            }, 1000);
        }
    }
    else {
        console.log("Wrong");
        playSound("wrong");
        $("body").addClass("game-over");
        setTimeout(function () {
            $("body").removeClass("game-over");
        }, 200);

        $("h1").text("Game-Over, Press Any key To restart");

        StartOver();
    }
}

function NextSequence() {

    userClickedPattern = [];
    //increase the level first
    level++;

    //update the h1
    $("#level-title").text("Level " + level);
    var randomNumber = Math.floor(Math.random() * 4);

    var randomChosenColor = buttonColors[randomNumber];

    gamePattern.push(randomChosenColor);

    $("#" + randomChosenColor).fadeIn(100).fadeOut(100).fadeIn(100);

    playSound(randomChosenColor);
}

function playSound(name) {
    var audio = new Audio("sounds/" + name + ".mp3");
    audio.play();
}
function animatepress(currentcolor) {
    $("#" + currentcolor).addClass("pressed");

    setTimeout(function () {
        $("#" + currentcolor).removeClass("pressed");
    }, 100);
}

function StartOver() {
    level = 0;
    gamePattern = [];
    started = false;
}
